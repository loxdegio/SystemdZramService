#include <QtWidgets/QApplication>
#include <QTranslator>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QFormLayout>
#include <QtWidgets/QTableWidget>
#include <QHeaderView>
#include <QProcess>
#include <QDebug>
#include <QtGlobal>
#include <unistd.h>

#include "tools.h"

QLineEdit *penter;
QStringList * myList = new QStringList;
QTableWidget *table;

void headerClick(int index)
{
    table->setSortingEnabled(true);
    table->sortByColumn(index, Qt::AscendingOrder);
    table->setSortingEnabled(false);

}

void onEnter()
{
    BuildFileList(table, myList, penter->text());
}

void onClick(int row, int column)
{
    QProcess open;
    QString comm = "xdg-open";
    QStringList args;
    QTableWidgetItem *value = table->item(row, column);
    if(column ==0)
    {
        QTableWidgetItem *value2 = table->item(row, column + 1);
        args << value2->text() + "/" + value->text();
    }
    else
        args << value->text();
    open.start(comm, args);
    open.waitForFinished();
}


int main(int argc, char **argv)
{
    QApplication app(argc, argv);

    QString locale = QLocale::system().name().section('_', 0, 0);
    QTranslator translator;
    translator.load(QString("/usr/lib/qtfind_i18n/qtfind_" + locale));
    app.installTranslator(&translator);

    if(argc > 2)
    {
        qFatal("\nError !!! Usage : qtfind [folderpath]\n");
        return -1;
    }
    else if(argc == 2)
    {
        qDebug() << argv[1];
        if(chdir(argv[1]) != 0)
            qFatal("\nError !!! Cannot open the destination folder.");
    }
        
    QWidget window;
    window.setWindowTitle(QObject::tr("File search"));
    QVBoxLayout *mainLayout = new QVBoxLayout;
    
    QLineEdit *pregexp = new QLineEdit();
    penter = pregexp;
    QObject::connect(pregexp, &QLineEdit::returnPressed, pregexp, onEnter);
    QFormLayout *layout = new QFormLayout;
    layout->addRow(QObject::tr("Search pattern"), pregexp);
    mainLayout->addLayout(layout);

    table = new QTableWidget;
    table->setSortingEnabled(false);

    QHeaderView * vueHeader = new QHeaderView(Qt::Horizontal);
    vueHeader->setSectionsMovable(true);
    vueHeader->setSectionsClickable(true);
    table->setHorizontalHeader(vueHeader);
    vueHeader -> setSectionResizeMode(QHeaderView::Stretch);
    table->setRowCount(0);
    table->setColumnCount(2);
    QStringList header;
    header << QObject::tr("File") << QObject::tr("Directory");
    table->setHorizontalHeaderLabels(header);
    QObject::connect(vueHeader, &QHeaderView::sectionClicked, &app, headerClick);

    QObject::connect(table, &QTableWidget::cellClicked, &app, onClick);

    mainLayout->addWidget(table);
    window.setLayout(mainLayout);
    window.resize(400, 500);
    window.show();
    return app.exec();
}
