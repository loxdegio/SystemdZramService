#include <QDebug>
#include <QTableWidget>
#include <QDir>
#include <QDirIterator>
#include <QRegExp>

void BuildFileList(QTableWidget *table,
                   QStringList *fileList, QString pattern)
{
    table->setSortingEnabled(false);
    QRegExp rx(pattern);
    rx.setCaseSensitivity(Qt::CaseInsensitive);
    fileList->clear();
    QDirIterator iterator("./", QDirIterator::Subdirectories);
    while (iterator.hasNext())
        {
        iterator.next();
        if (!iterator.fileInfo().isDir()) {
            QString fileName = iterator.fileName();
            if(fileName.contains(rx))
                {
                *fileList << iterator.filePath();
                }
        }
    }
    int row = 0;
    foreach(QString str, *fileList)
        {
        table->setRowCount(row + 1);
        table->setItem(row, 0, new QTableWidgetItem(str.section("/", -1, -1)));
        table->setCurrentCell(0,row);
        table->setItem(row, 1, new QTableWidgetItem(str.section("/", 0, -2)));
        row = row + 1;
        }
    table->setSortingEnabled(true);
    table->sortByColumn(0, Qt::AscendingOrder);
}

