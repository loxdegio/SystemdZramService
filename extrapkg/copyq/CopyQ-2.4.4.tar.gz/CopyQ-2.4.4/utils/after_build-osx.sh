#!/bin/bash
# Doesn't do anything on OS X because we can't run tests on OS X on Travis CI.
